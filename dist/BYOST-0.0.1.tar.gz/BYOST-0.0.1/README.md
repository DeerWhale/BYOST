# BYOT (Build Your Own Template)

Using Principal component analysis (PCA) and Gaussian process regression (GPR) to build spectral template based on two conditions. 

## Currently under construction, come check out later :)
